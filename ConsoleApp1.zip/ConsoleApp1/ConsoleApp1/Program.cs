﻿//using System.CodeDom.Compiler;
//using System.Collections.Generic;
//using System.Collections;
//using System.ComponentModel;
//using System.Diagnostics.CodeAnalysis;
//using System.Globalization;
//using System.IO;
//using System.Linq;
//using System.Reflection;
//using System.Runtime.Serialization;
//using System.Text.RegularExpressions;
//using System.Text;
//using System;

//class Solution
//{

   

//    static void Main(string[] args)
//    {
//        string strtext = Console.ReadLine();
//        Console.WriteLine(ConvertTextToNumber(strtext));


//    }

//    public static double ConvertTextToNumber(string text)
//    {
//        string[] units = new string[] {
//        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
//        "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
//        "sixteen", "seventeen", "eighteen", "nineteen",
//    };

//        string[] tens = new string[] { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

//        string[] scales = new string[] { "hundred", "thousand", "million", "billion", "trillion" };

//        Dictionary<string, ScaleIncrementPair> numWord = new Dictionary<string, ScaleIncrementPair>();
//        numWord.Add("and", new ScaleIncrementPair(1, 0));
//        for (int i = 0; i < units.Length; i++)
//        {
//            numWord.Add(units[i], new ScaleIncrementPair(1, i));
//        }

//        for (int i = 1; i < tens.Length; i++)
//        {
//            numWord.Add(tens[i], new ScaleIncrementPair(1, i * 10));
//        }

//        for (int i = 0; i < scales.Length; i++)
//        {
//            if (i == 0)
//                numWord.Add(scales[i], new ScaleIncrementPair(100, 0));
//            else
//                numWord.Add(scales[i], new ScaleIncrementPair(Math.Pow(10, (i * 3)), 0));
//        }

//        double current = 0;
//        double result = 0;

//        foreach (var word in text.Split(new char[] { ' ', '-', '—' }))
//        {
//            ScaleIncrementPair scaleIncrement = numWord[word];
//            current = current * scaleIncrement.scale + scaleIncrement.increment;
//            if (scaleIncrement.scale > 100)
//            {
//                result += current;
//                current = 0;
//            }
//        }
//        return result + current;
//    }


//    public struct ScaleIncrementPair
//    {
//        public double scale;
//        public int increment;
//        public ScaleIncrementPair(double s, int i)
//        {
//            scale = s;
//            increment = i;
//        }
//    }
//}
