﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Class1
    {
        static void Main(string[] args)
        {
            string inpstr = "the sky is zebra";
            int increament = 2;
            char[] alp = new char[] {' ','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
            char[] k = inpstr.ToArray();
            // string alpha = " abcdefghijklmnopqrstuvwxyz";
            string outstr = "";
            for (int i = 0; i < k.Length; i++)
            {
                int newindex;
                if (k[i]==','|| k[i] == '!'|| k[i] == '.'|| k[i] == ','|| k[i] == ' ')
                {
                    outstr = outstr + k[i];
                }
                else
                {
                    int ind = new string(alp).IndexOf(k[i]);
                    newindex = ind + increament;
                    if (newindex > 26)
                    {
                        newindex = newindex - 26;
                        outstr = outstr + alp[newindex];
                    }
                    else
                    {
                        outstr = outstr + alp[newindex];
                    }
                }
                
            }
           
            Console.WriteLine(outstr);
        }
    }
}
